package br.com.deschateie.beans;

import java.util.Calendar;
import java.util.Date;

public class Usuario {
	private int codigo;
	private String username;
	private String email;
	private String senha;
	private int nivelPermissao;
	private String nome;
	private int foto;
	private String genero;
	private String dataNasc;
	
	
	
	
	public Usuario() {
		super();
	}



	public Usuario(int codigo, String username, String email, String senha, 
			int nivelPermissao, String nome, int foto, String genero, String dataNasc) {
		super();
		setCodigo(codigo);
		setUsername(username);
		setEmail(email);
		setSenha(senha);
		setNivelPermissao(nivelPermissao);
		setNome(nome);
		setFoto(foto);
		setGenero(genero);
		setDataNasc(dataNasc);
	}



	public int getCodigo() {
		return codigo;
	}



	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}



	public String getUsername() {
		return username;
	}



	public void setUsername(String username) {
		this.username = username;
	}



	public String getEmail() {
		return email;
	}



	public void setEmail(String email) {
		this.email = email;
	}



	public String getSenha() {
		return senha;
	}



	public void setSenha(String senha) {
		this.senha = senha;
	}



	public int getNivelPermissao() {
		return nivelPermissao;
	}



	public void setNivelPermissao(int nivelPermissao) {
		this.nivelPermissao = nivelPermissao;
	}



	public String getNome() {
		return nome;
	}



	public void setNome(String nome) {
		this.nome = nome;
	}



	public int getFoto() {
		return foto;
	}



	public void setFoto(int foto) {
		this.foto = foto;
	}



	public String getGenero() {
		return genero;
	}



	public void setGenero(String genero) {
		this.genero = genero;
	}



	public String getDataNasc() {
		return dataNasc;
	}



	public void setDataNasc(String dataNasc) {
		this.dataNasc = dataNasc;
	}



	
	
}
