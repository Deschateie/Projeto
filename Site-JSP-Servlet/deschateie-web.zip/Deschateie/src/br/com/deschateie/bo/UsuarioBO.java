package br.com.deschateie.bo;

import br.com.deschateie.beans.Usuario;
import br.com.deschateie.dao.UsuarioDAO;

public class UsuarioBO {

	public static String novoUsuario(Usuario usuario) throws Exception{
		usuario.setEmail(usuario.getEmail().toUpperCase());
		usuario.setUsername(usuario.getUsername().toUpperCase());
		usuario.setNome(usuario.getNome().toUpperCase());
		
		if(usuario.getEmail().equals(null) || usuario.getEmail().length() < 6) {
			return "Email invalido";
		}
		if(usuario.getSenha().equals(null) || usuario.getSenha().length() < 3) {
			return "Senha invalida";
		}
		if(usuario.getUsername().equals(null) || usuario.getUsername().length() < 3) {
			return "Username invalido";
		}
		
		UsuarioDAO dao = new UsuarioDAO();
		
		if(usuario.getUsername().equals(dao.consultarPorUsername(usuario.getUsername()).getUsername())) {
			dao.fechar();
			return "Usuario ja existe";
		}
		
		if(usuario.getEmail().equals(dao.consultarPorEmail(usuario.getEmail()).getEmail())) {
			dao.fechar();
			return "Email j� usado";
		}
		
		
		
		dao.novoUsuario(usuario);
		dao.fechar();
		
		
		
		return "OK";
	}
	
}
