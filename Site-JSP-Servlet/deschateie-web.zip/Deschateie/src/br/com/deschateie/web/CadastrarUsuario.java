package br.com.deschateie.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.deschateie.beans.Usuario;
import br.com.deschateie.bo.UsuarioBO;

@WebServlet(urlPatterns = "/cadastrarUsuario")
public class CadastrarUsuario extends HttpServlet{

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		try {
			
			/* PEGANDO OS DADOS DO USUARIO VINDO DO FORMULARIO */
			int codigo = (int) (Math.random() * 190) / 2;
			String username = req.getParameter("username");
			String email = req.getParameter("email");
			String senha = req.getParameter("senha");
			int nivelPermissao = 1;
			String nome = req.getParameter("nome");
			String genero = req.getParameter("genero");
			String dataNasc = req.getParameter("dataNasc");
			
			Usuario usuarioNovo = new Usuario(codigo, username, email, senha, nivelPermissao, nome, 001, genero, dataNasc);
			
			req.setAttribute("dadosCadastro", usuarioNovo);
			
			String resultado = UsuarioBO.novoUsuario(usuarioNovo);
			
			if(!(resultado.equals("OK"))) {
				req.setAttribute("titulo", "falha no login :(");
				req.setAttribute("texto", resultado);
				req.setAttribute("status", "error");
				
				req.getRequestDispatcher("cadastro_usuario.jsp").forward(req, resp);
			}else {
				req.setAttribute("titulo", "Sucesso!");
				req.setAttribute("texto", "Cadastro efetivado com sucesso, poder� realizar o login agora mesmo.");
				req.setAttribute("status", "success");	
			
				req.getRequestDispatcher("login.jsp").forward(req, resp);
			}
			
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		
	}
	
	
}
