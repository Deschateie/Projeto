package br.com.deschateie.teste;

import java.util.Calendar;

public class TesteDate {
	
	public TesteDate() {}
	
	public Calendar data;
	
	public Calendar getData() {
		return this.data;
	}
	
	public void setData(Calendar data) {
		this.data = data;
	}

	public static void main(String[] args) {
		Calendar dia = Calendar.getInstance();
		
		dia.set(Calendar.DAY_OF_MONTH, 30);
		dia.set(Calendar.MONTH, (3+1));
		dia.set(Calendar.YEAR, 2000);
		
		
		TesteDate teste = new TesteDate();
		
		teste.setData(dia);
		
		System.out.println(teste.getData().get(teste.getData().YEAR));
	}
	
}
