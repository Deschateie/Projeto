package br.com.deschateie.teste;

import java.util.Calendar;
import java.util.Date;

import br.com.deschateie.beans.Usuario;
import br.com.deschateie.bo.UsuarioBO;
import br.com.deschateie.excecao.Excecao;

public class Conexao2 {

	public static void main(String[] args) {
		try {
			
			Usuario usuario = new Usuario(555, "MARCO", "MARCO@GMAIL.COM", 
					"123", 1, "MARCO ANTONIO BORGES OLIVEIRA", 1010, "MASCULINO", "20/02/2000");
			
			System.out.println(UsuarioBO.novoUsuario(usuario));
			
			/*
			Usuario usuario = dao.autenticarUsuario("MARCO", "123456");
			
			System.out.println(usuario.getCodigo());
			System.out.println(usuario.getEmail());
			System.out.println(usuario.getSenha());
			System.out.println(usuario.getUsername());
			System.out.println(usuario.getNivelPermissao());
			*/
		}catch(Exception e) {
			e.printStackTrace();
			System.out.println(Excecao.tratarExcecao(e));
		}
	}
}
