package br.com.deschateie.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Calendar;

import br.com.deschateie.beans.Usuario;
import br.com.deschateie.conexao.Conexao;

public class UsuarioDAO {

	private Connection con;
	private PreparedStatement stmt;
	private ResultSet rs;
	
	public UsuarioDAO() throws Exception{
		con = new Conexao().conectar();
	}
	
	public Usuario consultarPorUsername(String username) throws Exception{
		stmt = con.prepareStatement("SELECT * FROM T_SCP_USUARIO WHERE DS_LOGIN = ?");
		stmt.setString(1, username);
		
		rs = stmt.executeQuery();
		if(rs.next()) {
			return new Usuario(rs.getInt("CD_USUARIO"), rs.getString("DS_LOGIN"), 
					rs.getString("DS_EMAIL"), rs.getString("DS_SENHA"), 
					rs.getInt("NR_NIVEL_PERMISSAO"), rs.getString("NM_USUARIO"), rs.getInt("DS_FOTO"), rs.getString("DS_GENERO"), rs.getString("DT_NASCIMENTO"));
		}else {
			return new Usuario();
		}
	}
	
	public Usuario consultarPorEmail(String email) throws Exception{
		stmt = con.prepareStatement("SELECT * FROM T_SCP_USUARIO WHERE DS_EMAIL = ?");
		stmt.setString(1, email);
		
		rs = stmt.executeQuery();
		if(rs.next()) {
			return new Usuario(rs.getInt("CD_USUARIO"), rs.getString("DS_LOGIN"), 
					rs.getString("DS_EMAIL"), rs.getString("DS_SENHA"), 
					rs.getInt("NR_NIVEL_PERMISSAO"), rs.getString("NM_USUARIO"), rs.getInt("DS_FOTO"), rs.getString("DS_GENERO"), rs.getString("DT_NASCIMENTO"));
		}else {
			return new Usuario();
		}
	}
	
	public String novoUsuario(Usuario usuario) throws Exception{
		stmt = con.prepareStatement("INSERT INTO T_SCP_USUARIO(CD_USUARIO, DS_LOGIN, DS_SENHA, DS_EMAIL, NR_NIVEL_PERMISSAO, DT_NASCIMENTO, DS_GENERO, NM_USUARIO) VALUES (?,?,?,?,?,?,?,?)");
		
		stmt.setInt(1, usuario.getCodigo());
		stmt.setString(2, usuario.getUsername()); 
		stmt.setString(3, usuario.getSenha());
		stmt.setString(4, usuario.getEmail());
		stmt.setInt(5, usuario.getNivelPermissao());
		stmt.setString(6, usuario.getDataNasc());
		//stmt.setNull(7, null);
		stmt.setString(7, usuario.getGenero());
		stmt.setString(8, usuario.getNome());
		
		stmt.executeUpdate();
		
		con.close();
		
		return "Cadastrado com sucesso";
	
	}
	
	public Usuario autenticarUsuario(String username, String senha) throws Exception{
		stmt = con.prepareStatement("SELECT * FROM T_SCP_USUARIO WHERE DS_LOGIN = ? AND DS_SENHA = ?");
		
		stmt.setString(1, username);
		stmt.setString(2, senha);
		
		rs = stmt.executeQuery();
		
		
		
		if(rs.next()) {
			return new Usuario(rs.getInt("CD_USUARIO"), rs.getString("DS_LOGIN"), 
					rs.getString("DS_EMAIL"), rs.getString("DS_SENHA"), 
					rs.getInt("NR_NIVEL_PERMISSAO"), rs.getString("NM_USUARIO"), rs.getInt("DS_FOTO"), rs.getString("DS_GENERO"), rs.getString("DT_NASCIMENTO"));
		}else {
			return new Usuario();
		}
		
		//con.close();
		//return usuario;
	}
	
	public void fechar() throws Exception{
		con.close();
	}
}
